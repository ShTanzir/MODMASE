"""
Build a minified, deploy-ready copy of this site.

    pip install rjsmin rcssmin
    python build.py            # writes ../deploy

Keep this `source` folder private/readable; publish only the `deploy` folder.
"""
import os, re, shutil, sys
import rjsmin, rcssmin

SRC = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(os.path.dirname(SRC), "deploy")
SKIP = {"build.py", "README.md", ".git", "__pycache__"}

def min_html(s):
    s = re.sub(r"<!--(?!\[).*?-->", "", s, flags=re.S)   # strip comments
    s = re.sub(r"\s+", " ", s)                            # collapse whitespace
    s = re.sub(r">\s+<", "> <", s)
    return s.strip()

if os.path.exists(OUT):
    shutil.rmtree(OUT)
for root, dirs, files in os.walk(SRC):
    dirs[:] = [d for d in dirs if d not in SKIP]
    for f in files:
        if f in SKIP:
            continue
        sp = os.path.join(root, f)
        dp = os.path.join(OUT, os.path.relpath(sp, SRC))
        os.makedirs(os.path.dirname(dp), exist_ok=True)
        ext = f.rsplit(".", 1)[-1].lower()
        if ext == "html":
            open(dp, "w", encoding="utf8").write(min_html(open(sp, encoding="utf8").read()))
        elif ext == "css":
            open(dp, "w", encoding="utf8").write(rcssmin.cssmin(open(sp, encoding="utf8").read()))
        elif ext == "js":
            open(dp, "w", encoding="utf8").write(rjsmin.jsmin(open(sp, encoding="utf8").read()))
        else:
            shutil.copy2(sp, dp)
print("Built ->", OUT)
