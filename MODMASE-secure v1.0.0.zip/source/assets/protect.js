/*! MODMASE content protection (deterrent only - client-side code can always be bypassed) */
(function () {
  "use strict";
  var d = document, root = d.documentElement;
  root.classList.add("js");

  // Never interfere with search engines, link previews or automated audits.
  var ua = navigator.userAgent || "";
  var bot = navigator.webdriver ||
    /bot|crawl|spider|slurp|lighthouse|headless|pagespeed|googlebot|google-inspectiontool|adsbot|mediapartners|facebookexternalhit|whatsapp|telegrambot|preview/i.test(ua);
  if (bot) return;

  function stop(e) { e.preventDefault(); return false; }

  // Right-click, selecting, dragging, copying
  ["contextmenu", "selectstart", "dragstart", "copy", "cut"].forEach(function (t) {
    d.addEventListener(t, stop, true);
  });

  // Keyboard shortcuts: F12, view-source, save, print, select-all, inspect
  d.addEventListener("keydown", function (e) {
    var code = e.code || "";
    var ctrl = e.ctrlKey || e.metaKey;
    var bad =
      e.keyCode === 123 || code === "F12" ||
      (ctrl && e.shiftKey && /^Key[IJCKE]$/.test(code)) ||
      (ctrl && /^Key[USPA]$/.test(code)) ||
      (e.metaKey && e.altKey && /^Key[IJUC]$/.test(code));
    if (bad) { e.preventDefault(); e.stopPropagation(); return false; }
  }, true);

  // Developer-tools detection (desktop only)
  var coarse = window.matchMedia && window.matchMedia("(pointer: coarse)").matches;
  if (coarse) return;

  var overlay = null;

  function ensureOverlay() {
    if (overlay || !d.body) return;
    overlay = d.createElement("div");
    overlay.className = "dt-overlay";
    overlay.setAttribute("role", "alert");
    var h = d.createElement("h2");
    h.textContent = "Developer tools detected";
    var p = d.createElement("p");
    p.textContent = "Please close developer tools to keep browsing MODMASE.";
    overlay.appendChild(h);
    overlay.appendChild(p);
    d.body.appendChild(overlay);
  }

  function sizeOpen() {
    return (window.outerWidth - window.innerWidth > 200) ||
           (window.outerHeight - window.innerHeight > 200);
  }

  function debuggerOpen() {
    var t = performance.now();
    (function () { debugger; })();
    return performance.now() - t > 100;
  }

  setInterval(function () {
    var open = sizeOpen() || debuggerOpen();
    if (open) { ensureOverlay(); root.classList.add("dt-lock"); }
    else { root.classList.remove("dt-lock"); }
  }, 1000);
})();
