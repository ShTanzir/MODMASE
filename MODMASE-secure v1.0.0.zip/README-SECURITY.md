# MODMASE site - security update

- `deploy/`  -> push THIS folder's contents to your GitHub repo (minified, ready for Vercel)
- `source/`  -> readable source. Edit here, then run:  pip install rjsmin rcssmin && python build.py
               (build.py regenerates ../deploy). Don't publish `source/`.

## What was added
Headers (vercel.json): strict CSP (no inline JS/CSS, no third-party), HSTS, X-Frame-Options DENY,
frame-ancestors none, nosniff, Referrer-Policy, Permissions-Policy, COOP, CORP (anti-hotlink),
X-Permitted-Cross-Domain-Policies, /.well-known/security.txt, redirects for README/vercel.json/build.py.

Deterrents (assets/protect.js + style.css): text selection, right-click, drag, copy/cut, F12, Ctrl+U / Ctrl+S /
Ctrl+P / Ctrl+A, Ctrl+Shift+I/J/C/K/E, Cmd+Opt+I/J/U/C, print, DevTools detection (window-size + debugger timing)
with a lock overlay. Bots (Googlebot, Lighthouse, link previews) and touch devices are skipped so SEO is unaffected.

## Google Search Console
Minified HTML strips comments. Paste your verification meta tag directly into deploy/index.html <head>
(or uncomment it in source/index.html and rebuild).

## Be aware
Anything sent to a browser can be read: view-source:, curl, "Save as", or disabling JavaScript bypass these
deterrents. They stop casual users only. Never put secrets/API keys in this site.
